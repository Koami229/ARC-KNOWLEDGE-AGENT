# Pay-per-Knowledge AI Agent – Prototype pour Hackathon Agentic Economy on Arc

Ce dépôt implémente un agent IA autonome qui utilise les nanopaiements Circle et l'USDC sur Arc pour payer l'accès à des API de données premium et facturer l'utilisateur par réponse, à un coût inférieur à 0,01 $.

## 🚀 Installation et exécution (mode simulé)

### 1. Prérequis
- Node.js ≥ 18
- npm

### 2. Cloner et installer

\`\`\`bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install

# Scripts
cd ../scripts
npm install
\`\`\`

### 3. Configurer (optionnel)

Renommez `backend/.env.example` en `.env` et ajoutez votre clé API Gemini si vous voulez de vraies décisions IA (sinon, des décisions simulées par mots-clés sont utilisées).

### 4. Lancer le backend

\`\`\`bash
cd backend
npm run dev   # http://localhost:5000
\`\`\`

### 5. Lancer le frontend

\`\`\`bash
cd frontend
npm run dev   # http://localhost:3000
\`\`\`

### 6. Générer 50+ transactions pour la démo

\`\`\`bash
cd scripts
node generateTransactions.js
\`\`\`

Le dashboard (`http://localhost:3000/dashboard`) affichera en direct les transactions.

## 🔌 Brancher les vrais paiements Circle Arc

1. Créez un compte Circle Developer et récupérez vos clés.
2. Dans `backend/.env`, renseignez `CIRCLE_API_KEY` et `CIRCLE_SECRET`.
3. Remplacez le service `circleSimulator.js` par l'intégration réelle (voir commentaires dans le code).
4. Déployez un contrat de réception USDC sur le testnet Arc.
5. Adaptez le module pour utiliser le SDK Circle (`@circle-fin/sdk`) et x402.

## 📹 Vidéo de démonstration requise

Votre vidéo doit montrer :
- Une requête utilisateur déclenchée.
- L'appel à la console développeur Circle (vous pouvez montrer les logs simulés ou la vraie console).
- La vérification de la transaction sur l'explorateur Arc (affichage du hash).

## 📝 Commentaires produit Circle (à inclure dans la soumission)

**Produits utilisés** : Arc, USDC, Circle Nanopayments, Circle Wallets (recommandé), x402.
**Pourquoi** : Seuls les nanopaiements <0,01$ rendent ce modèle viable.
**Bonne expérience** : Documentation claire, SDK simple.
**Améliorations** : Un bac à sable gratuit avec wallets préchargés pour les hackathons.
**Recommandation** : Exemples complets x402 avec Node.js.

## ⚠️ Ce que vous devez faire vous-même

- Obtenir une clé Gemini (optionnelle) sur Google AI Studio.
- Créer un compte Circle pour le mode réel.
- Enregistrer la vidéo de démonstration selon les guidelines.
