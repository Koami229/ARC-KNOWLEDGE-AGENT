// script
export default function TransactionTable({ transactions }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full bg-gray-800 rounded-lg">
        <thead>
          <tr className="border-b border-gray-700">
            <th className="px-4 py-2 text-left">Tx Hash</th>
            <th className="px-4 py-2 text-left">Action</th>
            <th className="px-4 py-2 text-left">API</th>
            <th className="px-4 py-2 text-right">Montant (USDC)</th>
            <th className="px-4 py-2 text-right">Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx, i) => (
            <tr key={i} className="border-b border-gray-700 hover:bg-gray-700">
              <td className="px-4 py-2 text-xs font-mono text-green-300">
                {tx.txHash.slice(0, 10)}...
              </td>
              <td className="px-4 py-2 text-sm">{tx.action}</td>
              <td className="px-4 py-2 text-sm">{tx.api}</td>
              <td className="px-4 py-2 text-sm text-right">{tx.amountUSDC}</td>
              <td className="px-4 py-2 text-xs text-right text-gray-400">{tx.timestamp}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}