// script
import Link from 'next/link';

export default function Header() {
  return (
    <header className="bg-gray-800 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-xl font-bold text-green-400">🤖 Agentic Economy Arc</h1>
        <nav className="space-x-4">
          <Link href="/" className="hover:text-green-300">Accueil</Link>
          <Link href="/dashboard" className="hover:text-green-300">Dashboard</Link>
        </nav>
      </div>
    </header>
  );
}