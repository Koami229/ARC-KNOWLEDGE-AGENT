// script
export default function Footer() {
  return (
    <footer className="bg-gray-800 p-4 text-center text-sm text-gray-400">
      Built on Arc · Settled in USDC · Powered by Nanopayments
    </footer>
  );
}