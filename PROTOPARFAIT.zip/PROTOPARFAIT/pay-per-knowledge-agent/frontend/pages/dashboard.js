// script
import { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../components/Header';
import Footer from '../components/Footer';
import TransactionTable from '../components/TransactionTable';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000';

export default function Dashboard() {
  const [stats, setStats] = useState({ count: 0, totalAmount: 0, avgCost: 0, transactions: [] });
  const [loading, setLoading] = useState(true);

  const fetchTransactions = async () => {
    try {
      const { data } = await axios.get(`${BACKEND_URL}/api/transactions`);
      setStats(data);
    } catch (error) {
      console.error('Erreur chargement dashboard', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
    const interval = setInterval(fetchTransactions, 5000); // Actualisation toutes les 5 secondes
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto p-4 max-w-6xl">
        <h1 className="text-3xl font-bold mb-6">📊 Dashboard - Transactions on-chain</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-gray-800 p-6 rounded-lg">
            <p className="text-gray-400">Total transactions</p>
            <p className="text-3xl font-bold text-green-400">{stats.count}</p>
            <p className="text-sm text-gray-400">(≥ 50 requis)</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <p className="text-gray-400">Montant total réglé</p>
            <p className="text-3xl font-bold">{stats.totalAmount} USDC</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <p className="text-gray-400">Coût moyen par tx</p>
            <p className="text-3xl font-bold text-blue-400">{stats.avgCost} USDC</p>
            <p className="text-sm text-green-400">(≤ 0,01 $)</p>
          </div>
        </div>

        <h2 className="text-2xl font-semibold mb-4">🔍 Dernières transactions</h2>
        {loading ? (
          <p>Chargement...</p>
        ) : (
          <TransactionTable transactions={stats.transactions} />
        )}
      </main>
      <Footer />
    </div>
  );
}