// script
import { useState } from 'react';
import axios from 'axios';
import Header from '../components/Header';
import Footer from '../components/Footer';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000';

export default function Home() {
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);

  const askAgent = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    const userMsg = { type: 'user', text: question };
    setConversation((prev) => [...prev, userMsg]);

    try {
      const { data } = await axios.post(`${BACKEND_URL}/api/ask`, { question });
      const agentMsg = {
        type: 'agent',
        text: data.answer,
        api: data.apiUsed,
        cost: data.userCost,
        txHash: data.userPaymentTx,
      };
      setConversation((prev) => [...prev, agentMsg]);
    } catch (error) {
      const errMsg = {
        type: 'agent',
        text: 'Désolé, une erreur est survenue.',
        error: true,
      };
      setConversation((prev) => [...prev, errMsg]);
    } finally {
      setQuestion('');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto p-4 max-w-2xl">
        <h1 className="text-3xl font-bold mb-6 text-center">
          💸 Agent IA Pay-per-Knowledge
        </h1>
        <div className="bg-gray-800 p-4 rounded-lg mb-6 max-h-96 overflow-y-auto space-y-3">
          {conversation.map((msg, i) => (
            <div
              key={i}
              className={`p-3 rounded-lg ${
                msg.type === 'user'
                  ? 'bg-blue-600 ml-auto max-w-[80%]'
                  : 'bg-gray-700 mr-auto max-w-[80%]'
              }`}
            >
              <p className="text-sm">{msg.text}</p>
              {msg.cost && (
                <p className="text-xs mt-2 text-green-300">
                  Coût : {msg.cost} USDC | Tx : {msg.txHash.slice(0, 10)}...
                </p>
              )}
              {msg.api && <p className="text-xs text-gray-400">via {msg.api}</p>}
            </div>
          ))}
          {loading && <p className="text-gray-400 text-center">🤖 L'agent réfléchit...</p>}
        </div>

        <form onSubmit={askAgent} className="flex gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ex: Quel temps fait-il à Paris ?"
            className="flex-1 px-4 py-2 bg-gray-700 rounded-lg focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg font-semibold disabled:opacity-50"
          >
            Envoyer
          </button>
        </form>

        <div className="mt-8 bg-gray-800 p-4 rounded-lg text-sm">
          <h2 className="font-semibold mb-2">⚡ Pourquoi ce modèle est viable uniquement sur Arc ?</h2>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-600">
                <th className="py-1">Scénario</th>
                <th className="py-1">Frais de gas/tx</th>
                <th className="py-1">Coût pour 100 req.</th>
                <th className="py-1">Prix/req. viable</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="py-1">Ethereum L1</td>
                <td>~0,50 $</td>
                <td className="text-red-400">50,00 $</td>
                <td>❌ Non</td>
              </tr>
              <tr>
                <td className="py-1">Arc + Nanopayments</td>
                <td>~0,0046 $</td>
                <td className="text-green-400">0,46 $</td>
                <td>✅ Oui (≤0,01 $)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
      <Footer />
    </div>
  );
}