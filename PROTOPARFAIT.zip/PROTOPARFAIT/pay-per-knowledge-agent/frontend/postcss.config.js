// script
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};