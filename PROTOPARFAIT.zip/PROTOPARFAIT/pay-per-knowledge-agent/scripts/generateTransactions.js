// script
const axios = require('axios');

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:5000';

const questions = [
  // Météo
  "Quel temps fait-il à Abidjan ?",
  "Météo pour Paris",
  "Temps actuel à Tokyo",
  "Prévisions pour New York",
  "Quel est le climat à Lomé ?",
  "Météo Dakar",
  "Temps à Londres",
  "Météo pour Sydney",
  // Taux de change
  "Taux USD/EUR",
  "Change EUR/GBP",
  "Valeur du Bitcoin aujourd'hui",
  "Conversion USD/JPY",
  "Taux de change BTC/ETH",
  "Quel est le cours du dollar ?",
  // Actualités
  "Dernières nouvelles tech",
  "Actualités IA",
  "News blockchain",
  "Quoi de neuf dans les startups ?",
  "Actualités politiques",
  "Nouvelles technologies",
  // Mélange
  "Quel temps fait-il à Berlin ?",
  "Taux EUR/USD",
  "Dernières infos fintech",
  "Météo Singapour",
  "Cours du pétrole",
  "News économiques",
  "Météo Lagos",
  "Taux USD/CHF",
  "Dernières actualités scientifiques",
  "Quel temps fait-il à Nairobi ?",
  "Taux de change USD/KES",
  "Info Afrique",
  "Météo Le Caire",
  "Taux EUR/JPY",
  "Actualité crypto",
  "Météo Johannesburg",
  "Taux GBP/USD",
  "News environnement",
  "Météo Istanbul",
  "Taux USD/CNY",
  "Dernières nouvelles sportives",
  "Météo Moscou",
  "Taux EUR/CAD",
  "Actualités santé",
  "Météo Buenos Aires",
  "Taux USD/MXN",
  "News culture",
  "Météo Bangkok",
  "Taux USD/AUD",
  "Actualités monde",
  "Météo Madrid",
  "Taux USD/NZD",
];

async function generateTransactions() {
  console.log(`🚀 Génération de ${questions.length} requêtes vers ${BACKEND_URL}/api/ask\n`);
  let successCount = 0;

  for (const q of questions) {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/ask`, { question: q });
      console.log(`✅ "${q}" → ${response.data.apiUsed} (${response.data.userCost} USDC) [tx: ${response.data.userPaymentTx.slice(0, 10)}...]`);
      successCount++;
    } catch (error) {
      console.error(`❌ Erreur pour "${q}": ${error.message}`);
    }
    // Pause pour éviter la surcharge
    await new Promise(resolve => setTimeout(resolve, 300));
  }

  console.log(`\n🎉 ${successCount}/${questions.length} transactions générées avec succès.`);
  console.log(`Vérifiez le dashboard sur http://localhost:3000/dashboard`);
}

generateTransactions();