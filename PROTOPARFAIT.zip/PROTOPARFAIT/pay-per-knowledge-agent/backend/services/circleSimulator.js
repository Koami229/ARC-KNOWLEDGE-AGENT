// script
// Simule les nanopaiements Circle (en attendant le vrai SDK).
// En production, remplacez par l'intégration Circle réelle.
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const TRANSACTIONS_FILE = path.join(__dirname, '..', 'transactions.json');

/**
 * Lit les transactions depuis le fichier JSON.
 */
function readTransactions() {
  try {
    const data = fs.readFileSync(TRANSACTIONS_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

/**
 * Sauvegarde une transaction dans le fichier JSON.
 */
function saveTransaction(tx) {
  const txs = readTransactions();
  txs.push(tx);
  fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(txs, null, 2));
}

/**
 * Effectue un nanopaiement simulé.
 * @param {number} amountUSDC - Montant en USDC (ex: 0.0021)
 * @param {string} apiName - Nom de l'API cible
 * @param {string} action - Description de l'action
 * @returns {object} Détails de la transaction (hash, amount, etc.)
 */
async function sendPayment(amountUSDC, apiName, action) {
  // Simulation d'un délai de finalité (< 1s)
  await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 300));

  const txHash = `0x${uuidv4().replace(/-/g, '')}`; // Simulé, sera réel avec Circle
  const timestamp = new Date().toISOString();

  const transaction = {
    txHash,
    action,
    api: apiName,
    amountUSDC: parseFloat(amountUSDC.toFixed(4)),
    costTX: 0.0046, // Coût moyen observé sur Arc
    timestamp,
  };

  saveTransaction(transaction);
  console.log(`[SIMULATEUR] Paiement ${amountUSDC} USDC -> ${apiName} (${action}) [${txHash}]`);

  return transaction;
}

/**
 * Récupère toutes les transactions enregistrées.
 */
function getAllTransactions() {
  return readTransactions();
}

module.exports = {
  sendPayment,
  getAllTransactions,
};