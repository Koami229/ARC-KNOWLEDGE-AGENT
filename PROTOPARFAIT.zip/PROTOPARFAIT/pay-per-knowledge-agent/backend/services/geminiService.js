// script
// Service d'appel à Gemini (via API) ou simulation.
const axios = require('axios');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash:generateContent';

/**
 * Appelle Gemini pour déterminer quelle API utiliser et avec quels paramètres.
 * @param {string} userQuestion - Question de l'utilisateur
 * @returns {object} { api: 'WeatherAPI' | 'ExchangeRateAPI' | 'NewsAPI', params: object }
 */
async function decideAPI(userQuestion) {
  // Si pas de clé, on simule une décision simple
  if (!GEMINI_API_KEY) {
    console.log('[SIMULATION] Pas de clé Gemini, décision basée sur mots-clés');
    return simulateDecision(userQuestion);
  }

  // Appel réel à Gemini
  const prompt = `
Tu es un assistant qui sélectionne la meilleure API externe pour répondre à une question utilisateur.
APIs disponibles :
- WeatherAPI : pour la météo (ex: ville, région). Paramètres : { city: string }
- ExchangeRateAPI : pour les taux de change (ex: USD/EUR). Paramètres : { base: string, target: string }
- NewsAPI : pour les actualités. Paramètres : { topic: string }
Réponds UNIQUEMENT par un objet JSON valide de la forme : { "api": "WeatherAPI" | "ExchangeRateAPI" | "NewsAPI", "params": { ... } }.
Question : "${userQuestion}"
  `;

  const response = await axios.post(
    GEMINI_URL + '?key=' + GEMINI_API_KEY,
    {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.1 }
    }
  );

  const text = response.data.candidates[0].content.parts[0].text;
  // Extraire le JSON de la réponse (peut être entouré de ```json ... ```)
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('Réponse Gemini non JSON');
  return JSON.parse(jsonMatch[0]);
}

function simulateDecision(question) {
  const q = question.toLowerCase();
  if (q.includes('météo') || q.includes('temps') || q.includes('weather')) {
    const city = extractCity(question) || 'Abidjan';
    return { api: 'WeatherAPI', params: { city } };
  }
  if (q.includes('taux') || q.includes('change') || q.includes('eur') || q.includes('usd')) {
    return { api: 'ExchangeRateAPI', params: { base: 'USD', target: 'EUR' } };
  }
  if (q.includes('actualité') || q.includes('news') || q.includes('info')) {
    return { api: 'NewsAPI', params: { topic: 'tech' } };
  }
  // Par défaut, on prend NewsAPI pour tester
  return { api: 'NewsAPI', params: { topic: 'general' } };
}

function extractCity(question) {
  const regex = /(?:à|de|sur|in|at|dans)\s+([A-Za-zÀ-ÿ\s-]+)/;
  const match = question.match(regex);
  return match ? match[1].trim() : null;
}

module.exports = { decideAPI };