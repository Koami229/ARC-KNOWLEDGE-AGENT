// script
const express = require('express');
const router = express.Router();
const { getAllTransactions } = require('../services/circleSimulator');

// GET /api/transactions
router.get('/transactions', (req, res) => {
  const txs = getAllTransactions();
  // Calculer des statistiques
  const totalAmount = txs.reduce((sum, tx) => sum + tx.amountUSDC, 0);
  const avgCost = txs.length ? totalAmount / txs.length : 0;
  res.json({
    count: txs.length,
    totalAmount: parseFloat(totalAmount.toFixed(4)),
    avgCost: parseFloat(avgCost.toFixed(4)),
    transactions: txs.reverse(), // Les plus récentes en premier
  });
});

// POST /api/generate-proof (génère un lot de transactions pour la démo)
// Le vrai script est dans scripts/generateTransactions.js
module.exports = router;