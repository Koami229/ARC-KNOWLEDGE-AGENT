// script
const express = require('express');
const router = express.Router();
const { decideAPI } = require('../services/geminiService');
const { fetchPremiumData, getAPICost } = require('../services/dataApi');
const { sendPayment } = require('../services/circleSimulator');

// POST /api/ask
router.post('/ask', async (req, res) => {
  try {
    const { question } = req.body;
    if (!question || question.trim() === '') {
      return res.status(400).json({ error: 'Question requise' });
    }

    // 1. L'agent IA décide de l'API à utiliser
    const decision = await decideAPI(question);
    const api = decision.api;
    const params = decision.params;

    // 2. Prix de l'appel API
    const apiCost = getAPICost(api);

    // 3. Paiement nanopayment vers l'API
    const paymentTx = await sendPayment(apiCost, api, `Accès ${api} pour "${question}"`);

    // 4. Récupération des données
    const premiumData = await fetchPremiumData(api, params);

    // 5. L'agent facture l'utilisateur (paiement simulé utilisateur -> plateforme)
    const userCost = 0.0035; // Légère marge pour la plateforme
    const userPaymentTx = await sendPayment(userCost, 'Platform', `Frais utilisateur pour "${question}"`);

    // 6. Réponse finale
    res.json({
      answer: premiumData.data,
      apiUsed: api,
      apiCost,
      userCost,
      paymentTx: paymentTx.txHash,
      userPaymentTx: userPaymentTx.txHash,
      transactionCount: 2, // Comptage symbolique
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Erreur interne' });
  }
});

module.exports = router;