// script
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const askRoute = require('./routes/ask');
const transactionsRoute = require('./routes/transactions');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use('/api', askRoute);
app.use('/api', transactionsRoute);

// Health check
app.get('/', (_, res) => res.send('Backend is running'));

app.listen(PORT, () => {
  console.log(`✅ Backend listening on http://localhost:${PORT}`);
});